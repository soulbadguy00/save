.. _changelog:

Changelog
=========

`Version 1.0 (24-04-2020)`
-------------------------
- First release for Odoo 12.0.
